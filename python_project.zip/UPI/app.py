from flask import Flask, render_template, request, jsonify
import numpy as np
from sklearn.preprocessing import StandardScaler
import pandas as pd
from model import prediction  

app = Flask(__name__)
scaler = StandardScaler()

data = pd.read_csv(r'.\static\dataset\upi_data.csv')
scaler.fit_transform(data.values) 

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # balance_diff = int(request.form.get('balance_diff'))
        payment_method = np.float64(request.form.get('payment_method'))
        amount = np.float64(request.form.get('amount'))
        initial_balance = np.float64(request.form.get('initial_balance'))
        final_balance = np.float64(request.form.get('final_balance'))
        balance_diff = abs(initial_balance-final_balance)
        
        x_input = np.array([[payment_method, amount, initial_balance, final_balance, balance_diff]]).reshape(-1,1)
        x_input_scaled = scaler.fit_transform(x_input)
        
        fraud_prediction = prediction(x_input_scaled[0][0],x_input_scaled[1][0], x_input_scaled[2][0], x_input_scaled[3][0], x_input_scaled[4][0])  
        if fraud_prediction:
            fraud_code = "Fraud Detected"
        else:
            fraud_code = "No Fraud Detected"
        return jsonify({'fraud_code': fraud_code})
    return render_template('index3.html')

if __name__ == '__main__':
    app.run(debug=True)
