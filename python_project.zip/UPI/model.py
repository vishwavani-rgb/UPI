import numpy as np
import pickle
import warnings
warnings.filterwarnings('ignore')
model_filename = 'xgb_classifier_model.pkl'
with open(model_filename, 'rb') as file:
    loaded_model = pickle.load(file)

def prediction(type, amount, oldbalanceOrg, newbalanceOrig, balance_diff):
    
    # print([type, amount, oldbalanceOrg, newbalanceOrig, balance_diff])
    if loaded_model.predict([[type, amount, oldbalanceOrg, newbalanceOrig, balance_diff]])[0] == 0:
        pred = False
    else:
        pred = True
        
    return pred

def predictor(arr):
    print('array is ', arr,  abs(arr[1]-arr[2]))
    try:
        if arr[3] < abs(arr[1]-arr[2]):
            return True
        elif abs(arr[1]-arr[2]) == arr[3]:
            return False
        else:
            return False
    except Exception as e:
        return e
        
    

    
